/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package comp228lab2Exercise1;

/**
 *
 * @author faiaz
 */
public class TestMain {
     //Creating test object and running the test
    public static void main(String[] args) {
         //Creating test object and running the test
        Test myTest = new Test();
        myTest.startTest();
    }
}
      
      
